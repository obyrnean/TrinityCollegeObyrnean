// Import libraries needed
import express from 'express';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config(); // Load .env file (API stored here, change the key to your own!)
const app = express();
const PORT = process.env.PORT || 3000;

// Provide frontend files (index.html, style.css, app.js)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(__dirname));

// OpenWeatherMap API base URL
const BASE_URL = 'https://api.openweathermap.org/data/2.5';
const API_KEY = process.env.OPENWEATHER_API_KEY;

//console.log('API Key:', API_KEY); // To check API key its using

// Communication from frontend to the server to fetch data:
// 1. Current Weather:
app.get('/api/current', async (req, res) => {
  const city = req.query.city;
  const url = `${BASE_URL}/weather?q=${encodeURIComponent(city)}&units=metric&appid=${API_KEY}`;
  try {
    const r = await fetch(url);
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Forecast Info:
app.get('/api/forecast', async (req, res) => {
  const city = req.query.city;
  const url = `${BASE_URL}/forecast?q=${encodeURIComponent(city)}&units=metric&appid=${API_KEY}`;
  try {
    const r = await fetch(url);
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Pollution:
app.get('/api/air_pollution', async (req, res) => {
  const { lat, lon } = req.query;
  const url = `${BASE_URL}/air_pollution?lat=${lat}&lon=${lon}&appid=${API_KEY}`;
  try {
    const r = await fetch(url);
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Use the html file (index.html) as default 
app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

//Start Server and link to app (Type "npm start" in terminal to do so! And "Ctrl C" to close server)
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
