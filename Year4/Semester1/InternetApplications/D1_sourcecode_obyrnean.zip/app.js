const { createApp } = Vue; // Vue Application

createApp({
  data() { // Reactive variables for Vue to update (and their default settings)
    return {
      city: '',
      displayName: '--',
      loaded: false,
      currentTemp: null,
      currentIcon: '',
      forecastDays: [],    
      forecastRaw: [],     
      selectedIndex: 0,
      details: {
        name: '--',
        temp: 0,
        description: '--',
        advice: '--',
        wind: 0,
        rain: 0
      },
      pollution: {
        aqi: null,
        aqiText: '--',
        components: {},
        warning: ''
      },
      gameActive: false,
      outfitItems: [ // Change the path depending on where your images have been saved (must be same folder as code files)
        { id: 'scarf', img: 'Images/scarf.png' },
        { id: 'jacket', img: 'Images/coat.png' },
        { id: 'jumper', img: 'Images/hoodie.png' },
        { id: 'shirt', img: 'Images/shirt.png' },
        { id: 'longPants', img: 'Images/longpants.png' },
        { id: 'shortPants', img: 'Images/shorts.png' },
        { id: 'shoes', img: 'Images/shoes.png' },
        { id: 'boots', img: 'Images/boots.png' }
      ],
      selectedOutfitArr: [],
      selectedWeekday: '--'
    };
  },
  // INTERACTIVE OUTFIT GAME:
  computed: { // Values that will automatically update
  selectedOutfit() {
    return new Set(this.selectedOutfitArr); // Array of chosen outfits without repetitions
  },
  totalWarmth() { // Points to compare with actual weather
    const warmthPoints = { 
      scarf: 2, 
      jacket: 4, 
      jumper: 3, 
      shirt: 1,
      longPants: 2, 
      shortPants: 1, 
      shoes: 1, 
      boots: 2
    };
    return this.selectedOutfitArr.reduce((total, id) => total + (warmthPoints[id] || 0), 0);
  },
  outfitFeedback() { //Feedback based on if the chosen clothes are appropriate for the temperature
    const t = this.currentTemp;
    if (t === null || t === undefined) return '';
    const total = this.totalWarmth;
    let feedback = '';

    if (t < 10) {
      feedback = total < 13
        ? "It will be too cold, try adding another layer!"
        : "Great choice! Ready for chilly weather!";
    } else if (t >= 10 && t < 20) {
      feedback = total < 7
        ? "Might be a bit cool, maybe add another layer."
        : total > 11
        ? "Too warm, try removing a layer!"
        : "Great choice! Ready to go for today!";
    } else if (t >= 20 && t < 25) {
      feedback = total < 4
        ? "Might be a bit cool, maybe add another layer."
        : total > 6
        ? "Too warm, try removing a layer!"
        : "Great choice! Ready to go for a warm day!";
    } else {
      feedback = total >= 4
        ? "It will be a bit warm, try removing a layer."
        : total === 0
        ? "Let's add some layers!"
        : total < 3
        ? "Let's add more layers!"
        : "Great choice! Ready for a very warm day! Make sure not to forget sunscreen :]";
    }

    return feedback;
  }
},
// WEATHER UPDATES:
  methods: {
    async getWeather() {
      if (!this.city || !this.city.trim()) {
        return alert('Please enter a city name.'); // Note pops if no city has been entered to fetch data from
      }

      try {
        // Current weather of typed city fetch from server
        const curResp = await fetch(`/api/current?city=${encodeURIComponent(this.city.trim())}`);
        if (!curResp.ok) throw new Error('Current weather request failed');
        const currentData = await curResp.json(); // Server Json reply

        // Update current weather display with API info
        this.displayName = currentData.name || this.city;
        this.currentTemp = currentData.main.temp;
        const icon = currentData.weather[0].icon;
        this.currentIcon = `<img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="icon">`;

        // Details of info table
        this.details = {
          name: this.displayName,
          temp: currentData.main.temp,
          description: currentData.weather[0].description,
          advice: (currentData.weather[0].main.toLowerCase().includes('rain') ? 'Bring an umbrella!' : 'No umbrella needed.'),
          wind: currentData.wind ? currentData.wind.speed : 0,
          rain: currentData.rain ? (currentData.rain['1h'] || 0) : 0
        };

        // Forecast (want information from current and next 3 days)
        const fResp = await fetch(`/api/forecast?city=${encodeURIComponent(this.city.trim())}`);
        if (!fResp.ok) throw new Error('Forecast request failed');
        const fData = await fResp.json(); //Server Json reply

        // As well as coordinates for pollution section
        this.forecastRaw = (fData.list || []).map(item => ({ ...item, coord: currentData.coord || {} }));
 
        this.forecastDays = this.forecastRaw.filter((_, i) => i % 8 === 0).slice(0, 4).map(item => ({ // 4 days display
          weekday: new Date(item.dt_txt).toLocaleDateString('en-US', { weekday: 'long' }), 
          icon: `<img src="https://openweathermap.org/img/wn/${item.weather[0].icon}@2x.png" alt="ficon">`,
          temp: item.main.temp,
          raw: item
        }));

        // Default selected day to be current day
        this.selectedIndex = 0;
        if (this.forecastDays.length) this.selectDay(0);

        // Pollution for current coordinates
        if (currentData.coord) {
          await this.getPollution(currentData.coord.lat, currentData.coord.lon);
        }

        this.loaded = true;
        this.selectedWeekday = new Date().toLocaleDateString('en-US', { weekday: 'long' });

      } catch (err) {
        console.error('getWeather error', err);
        alert('Error fetching weather data. Check server or network console.');
      }
    },

    // Select day from forecastDays (updates details and pollution accordingly as well as for interactive outfit game)
    async selectDay(idx) {
      const f = this.forecastDays[idx];
      if (!f) return;
      this.selectedIndex = idx;
      this.currentTemp = f.temp;
      this.currentIcon = f.icon;
      this.details = {
        name: this.displayName,
        temp: f.temp,
        description: f.raw.weather[0].description,
        advice: (f.raw.weather[0].main.toLowerCase().includes('rain') ? 'Bring an umbrella!' : 'No umbrella needed.'),
        wind: f.raw.wind ? f.raw.wind.speed : 0,
        rain: f.raw.rain ? (f.raw.rain['1h'] || 0) : 0
      };
      this.selectedWeekday = f.weekday;

      // Pollution infor for the coordinates of selected day and update feedback
      const lat = f.raw.coord && f.raw.coord.lat ? f.raw.coord.lat : (this.forecastRaw[0]?.coord?.lat);
      const lon = f.raw.coord && f.raw.coord.lon ? f.raw.coord.lon : (this.forecastRaw[0]?.coord?.lon);
      if (lat && lon) {
        await this.getPollution(lat, lon);
      }
    },

    // POLLUTION:
    async getPollution(lat, lon) { // Pollution information fetch from server 
  try {
    const pResp = await fetch(`/api/air_pollution?lat=${lat}&lon=${lon}`);
    if (!pResp.ok) throw new Error('Pollution request failed');
    const pData = await pResp.json();
    if (!pData.list || !pData.list.length) {
      this.pollution = { aqiText: 'Unavailable', components: {}, warning: '' };
      return;
    }

    const components = pData.list[0].components; // List of found pollutants

    // AQI info (Air Quality Information)
    const aqi = pData.list[0].main.aqi;
    const aqiText = ["Good","Fair","Moderate","Poor","Very Poor"][aqi-1] || "Unknown";
    this.pollution.aqi = aqi;
    this.pollution.aqiText = `${aqi} -> ${aqiText}`;
    this.pollution.components = components;

    // Elevated pollutants
    const elevated = [];
        /*if (components.pm2_5 > 12) warnings.push(`PM2.5 is ${components.pm2_5} μg/m³ (Elevated, can affect lungs and aggravate asthma).`);
        if (components.pm10 > 20) warnings.push(`PM10 is ${components.pm10} μg/m³ (Elevated, can trigger allergies and respiratory irritation).`);
        if (components.co > 1000) warnings.push(`CO is ${components.co} μg/m³ (Elevated, reduces oxygen delivery in the body).`);
        if (components.no > 40) warnings.push(`NO is ${components.no} μg/m³ — Can oxidize to NO2, irritating airways and worsening asthma.`);
        if (components.no2 > 40) warnings.push(`NO2 is ${components.no2} μg/m³ (Elevated, irritates airways and worsens asthma).`);
        if (components.o3 > 100) warnings.push(`O3 is ${components.o3} μg/m³ — Ground-level ozone can cause coughing, throat irritation, and chest pain.`);
        if (components.so2 > 20) warnings.push(`SO2 is ${components.so2} μg/m³ — Can cause breathing difficulties and aggravate existing lung diseases.`);
        if (components.nh3 > 200) warnings.push(`NH3 is ${components.nh3} μg/m³ — Ammonia exposure can irritate eyes, nose, and throat.`);
        //NEED RO ADD MORE OF THE POLLUTANTS THAT DISPLAY*/

    // Check quality level and give feedback if good or not
    function assessLevel(name, value, levels) {
      for (let i = levels.length - 1; i >= 0; i--) {
        if (value > levels[i].limit) {
          elevated.push({
            name,
            value,
            label: levels[i].label,
            color: levels[i].color,
            effect: levels[i].effect
          });
          return;
        }
      }
    }

    assessLevel("PM2.5", components.pm2_5, [
      { limit: 75, label: "Very High", color: "red", effect: "Dangerous for everyone, stay indoors." },
      { limit: 35, label: "High", color: "orange", effect: "Unhealthy for sensitive groups." },
      { limit: 12, label: "Moderate", color: "goldenrod", effect: "Slight irritation possible." }
    ]);

    assessLevel("PM10", components.pm10, [
      { limit: 150, label: "Very High", color: "red", effect: "Can worsen asthma." },
      { limit: 50, label: "High", color: "orange", effect: "May irritate children and elderly." },
      { limit: 20, label: "Moderate", color: "goldenrod", effect: "Slightly elevated." }
    ]);

    assessLevel("CO", components.co, [
      { limit: 10000, label: "Very High", color: "red", effect: "Toxic, avoid exposure." },
      { limit: 2000, label: "High", color: "orange", effect: "Reduced oxygen delivery." },
      { limit: 1000, label: "Moderate", color: "goldenrod", effect: "Slightly elevated." }
    ]);

    assessLevel("NO", components.no, [
      { limit: 100, label: "Very High", color: "red", effect: "Can damage lungs." },
      { limit: 60, label: "High", color: "orange", effect: "Irritates airways." },
      { limit: 40, label: "Moderate", color: "goldenrod", effect: "Slightly elevated." }
    ]);

    assessLevel("NO2", components.no2, [
      { limit: 200, label: "Very High", color: "red", effect: "Severe airway irritation." },
      { limit: 100, label: "High", color: "orange", effect: "Worsens asthma." },
      { limit: 40, label: "Moderate", color: "goldenrod", effect: "Slight irritation possible." }
    ]);

    assessLevel("O3", components.o3, [
      { limit: 180, label: "Very High", color: "red", effect: "Harmful to breathe." },
      { limit: 120, label: "High", color: "orange", effect: "Uncomfortable for sensitive groups." },
      { limit: 100, label: "Moderate", color: "goldenrod", effect: "Slight irritation." }
    ]);

    assessLevel("SO2", components.so2, [
      { limit: 150, label: "Very High", color: "red", effect: "Breathing difficulties possible." },
      { limit: 50, label: "High", color: "orange", effect: "Unhealthy for asthmatics." },
      { limit: 20, label: "Moderate", color: "goldenrod", effect: "Slightly elevated." }
    ]);

    assessLevel("NH3", components.nh3, [
      { limit: 1000, label: "Very High", color: "red", effect: "Toxic at high levels." },
      { limit: 400, label: "High", color: "orange", effect: "Can cause discomfort." },
      { limit: 200, label: "Moderate", color: "goldenrod", effect: "Mild irritation." }
    ]);

    // Pollutant feedback warnings and list of which are elevanted
    if (elevated.length === 0) {
      this.pollution.warning = `<span style="color:green;">All measured pollutants are within 'Good' levels.</span>`;
    } else {
      let msg = `<span style="color:red;">Warning: Elevated pollutant levels detected!</span><br><br>`;
      elevated.forEach(p => {
        msg += `<b>${p.name}</b>: ${p.value} μg/m³ —> <span style="color:${p.color}">${p.label}</span>. ${p.effect}<br>`;
      });
      this.pollution.warning = msg;
    }

  } catch (err) {
    console.error('getPollution error', err);
    this.pollution = { aqiText: 'Unavailable', components: {}, warning: '' };
  }
},
    // INTERACTIVE GAME:
    toggleItem(id) { // Add or remove items with button click
      const index = this.selectedOutfitArr.indexOf(id);
      if (index === -1) {
        this.selectedOutfitArr.push(id);
      } else {
        this.selectedOutfitArr.splice(index, 1);
      }
    },

    onEnterKey() { // Can also press enter to search for city info instead of button
      this.getWeather();
    }
  },

  mounted() { // Write here if wanted a message to appear on terminal 
  }
}).mount('#app'); // Vue App built